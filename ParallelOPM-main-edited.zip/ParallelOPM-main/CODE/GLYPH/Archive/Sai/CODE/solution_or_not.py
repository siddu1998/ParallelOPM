import json

#given a board state determine the board_state is a solution
#or not based on the subsequent data from the log file


